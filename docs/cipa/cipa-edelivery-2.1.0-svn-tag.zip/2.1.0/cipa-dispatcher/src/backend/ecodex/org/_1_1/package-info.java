@javax.xml.bind.annotation.XmlSchema(namespace = "http://org.ecodex.backend/1_1/")
package backend.ecodex.org._1_1;
