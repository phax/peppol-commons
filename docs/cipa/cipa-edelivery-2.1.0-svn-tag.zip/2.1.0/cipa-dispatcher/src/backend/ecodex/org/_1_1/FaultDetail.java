
package backend.ecodex.org._1_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="code">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ERROR_GENERAL_001"/>
 *               &lt;enumeration value="ERROR_GENERAL_002"/>
 *               &lt;enumeration value="ERROR_GENERAL_003"/>
 *               &lt;enumeration value="ERROR_SEND_001"/>
 *               &lt;enumeration value="ERROR_SEND_002"/>
 *               &lt;enumeration value="ERROR_SEND_003"/>
 *               &lt;enumeration value="ERROR_SEND_004"/>
 *               &lt;enumeration value="ERROR_SEND_005"/>
 *               &lt;enumeration value="ERROR_DOWNLOAD_001"/>
 *               &lt;enumeration value="ERROR_DOWNLOAD_002"/>
 *               &lt;enumeration value="ERROR_DOWNLOAD_003"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="message" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "code",
    "message"
})
@XmlRootElement(name = "FaultDetail")
public class FaultDetail {

    @XmlElement(required = true)
    protected String code;
    @XmlElement(required = true, nillable = true)
    protected String message;

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

}
