@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/ebxml-msg/ebms/v3.0/ns/core/200704/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.oasis_open.docs.ebxml_msg.ebms.v3_0.ns.core._200704;
