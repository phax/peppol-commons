@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2003/05/soap-envelope", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.w3._2003._05.soap_envelope;
