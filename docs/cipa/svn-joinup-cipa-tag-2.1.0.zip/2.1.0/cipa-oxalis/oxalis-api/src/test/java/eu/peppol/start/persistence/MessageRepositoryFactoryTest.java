package eu.peppol.start.persistence;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

/**
 * @author $Author$ (of last change)
 *         Created by
 *         User: steinar
 *         Date: 28.11.11
 *         Time: 21:12
 */
public class MessageRepositoryFactoryTest {

    @Test
    public void testGetInstance() {
        // assertEquals(MessageRepositoryFactory.getInstanceNoDefault().toString(), SimpleMessageRepository.SIMPLE_MESSAGE_REPOSITORY_CLASS_SAYS_HELLO_WORLD);
    }
}
